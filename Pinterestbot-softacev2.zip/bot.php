<?php

include 'config.php';

/* Bağlantıyı Başlat */
$mysqli = new mysqli($host,$vkad,$vsif,$vad);/* Bağlantıyı Kontrol Et */
if ($mysqli->connect_error){
    /* Bağlantı Başarısız İse */
    echo "Bağlantı Başarısız. Hata: " . $mysqli->connect_error;
    exit;
}



$mysqli->set_charset("utf8");

$sorgu2 = $mysqli->query("SELECT mail,sifre,kadi,delay,miktar,durum FROM bot");

$cikti = $sorgu2->fetch_array();





	


require __DIR__ . '/vendor/autoload.php';

use seregazhuk\PinterestBot\Factories\PinterestBot;


if ($cikti["miktar"]==$cikti["durum"]) {
	echo "başa";
	die();
}


	# code...

	# code...

$bot = PinterestBot::create();
//$bot->getHttpClient()->useProxy("109.236.48.40", "2079","e9466e6f:e9466e6f");
$bot->auth->login($cikti["mail"],$cikti["sifre"]);

if ($bot->user->isBanned()) {
    echo "Hesabınız Banlanmıştır.";
    die();
}

// get board id
$boards = $bot->boards->forUser($cikti["kadi"]);
$boardId = $boards[0]['id'];
$i=rand(1,100);
// select image for posting
$y=0;
while ($y <= 1) {
$y++;


$images = glob('resim/*.*');
if(empty($images)) {
    echo "Resimsiz İşlem Olmaz.";
    die();
}




// select keyword

$sorgu1 = $mysqli->query("SELECT * from anahtar order by rand() limit 1");





$cikti1 = $sorgu1->fetch_array();

$keyword = "#".$cikti1['kelime'];

$deg=rand(999,99999);
$blogUrl = 'https://sosyalonline.com/pinteres/blogoku.php?id='.$deg;






$dermi=rand(1,5900);
$json_url = "https://wallhaven.cc/api/v1/search?&categories=$dermi&purity=100&sorting=random&order=desc"; //adresi
$json_file = file_get_contents($json_url, true);
$api = json_decode($json_file);
//$id=$api->data[0]->path;
$id=$api->data;

//print_r($id);
$i=0; //dizi index

 echo $link=$id=$api->data[$i]->path;
$curl = curl_init();
curl_setopt($curl , CURLOPT_URL , $link);
curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl , CURLOPT_FOLLOWLOCATION, true);
$veri = curl_exec($curl);
curl_close($curl);
 $isim=rand(1,99999999);
 $yer="resimm/".$isim.".jpg";
file_put_contents($yer,$veri);

   
$image = $yer;
$sorgu2 = $mysqli->query("INSERT INTO blog (id,isim,aciklama,url) VALUES ('$deg','$keyword','$keyword','$yer')");
$bot->pins->create($image, $boardId, $keyword, $blogUrl);





 





	

	sleep($cikti["delay"]);


$durum2=$cikti['durum']++;
$mysqli->set_charset("utf8");
//resimi nasıl alacak la .D nerden cekcek resimi klasör resimlerin adını cekmemiz lazım şimdi onu denicem
$sorgu = $mysqli->query("UPDATE bot SET durum = $durum2 WHERE id = 1");


echo $image;

// remove image

}

?>