<?php
include 'config.php';

/* Bağlantıyı Başlat */
$mysqli = new mysqli($host,$vkad,$vsif,$vad);/* Bağlantıyı Kontrol Et */
if ($mysqli->connect_error){
    /* Bağlantı Başarısız İse */
    echo "Bağlantı Başarısız. Hata: " . $mysqli->connect_error;
    exit;
}




$userler = file("anahtar.txt");
$satirsayisi = count($userler);
for ($i=0; $i <$satirsayisi ; $i++) { 
$deger = explode(',',$userler[$i]);
$username = $deger[0];
$simdi = date('d.m.Y H:i:s');
mysqli_query($mysqli,"INSERT INTO anahtar (kelime) VALUES ('$username')");
}











?>