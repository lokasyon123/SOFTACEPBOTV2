<?php



include 'config.php';



$mysqli = new mysqli($host,$vkad,$vsif,$vad);/* Bağlantıyı Kontrol Et */
if ($mysqli->connect_error){
    /* Bağlantı Başarısız İse */
    echo "Bağlantı Başarısız. Hata: " . $mysqli->connect_error;
    exit;
}

$id=$_GET['id'];

$sonuc=mysqli_query($mysqli,"select * from blog  ORDER BY rand() limit 1"); 
mysqli_set_charset($mysqli, "utf8");

while($satir=mysqli_fetch_array($sonuc))
{
 $ss=$satir['id'];
 $tt=$satir['aciklama'];
}



$sql="SELECT * FROM blog WHERE id=$id";
$result=mysqli_query($mysqli,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$s=mysqli_num_rows($result);


if ($s==1) {
     
}elseif ($s==0) {
   
}


try {

    $baglanti = new PDO("mysql:host=$host;dbname=$vad", "$vkad", "$vsif");
    $baglanti->exec("SET NAMES utf8");
    $baglanti->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sorgu = $baglanti->query("SELECT id, isim, aciklama , url , time FROM blog where id=$id");
 $cikti = $sorgu->fetch(PDO::FETCH_ASSOC);

   
    

} catch (PDOException $e) {
    die($e->getMessage());
}

$baglanti = null;



$cikti['isim'];



 ?>

<!DOCTYPE html>
<html lang="en">
<head> 

     <title>Sosyal Online - <?php echo $cikti['isim'];  ?></title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="<?php echo $cikti['isim'];  ?>">
     <meta name="keywords" content="<?php echo $cikti['isim'];  ?>">
     <meta name="author" content="CLKSOFT">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">
</head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130594883-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130594883-1');
</script>

<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.php" class="navbar-brand">SOFTACE</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="#home" class="smoothScroll">Ana Sayfa</a></li>
                        
                         <li><a href="#blog" class="smoothScroll">Blog</a></li>
                         
                         <li><a href="#contact" class="smoothScroll">İletişim</a></li>
                    </ul>

                   
               </div>

          </div>
     </section>


     <!-- BLOG HEADER -->
     <section id="blog-header" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-1 col-md-5 col-sm-12">
                         <h2>Resim ile alakalı her şeyi Okuyabilirsiniz.</h2>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- BLOG DETAIL -->
     <section id="blog-detail" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row"> 

                    <div class="col-md-offset-1 col-md-10 col-sm-12">
                         <!-- BLOG THUMB -->
                         <div class="blog-detail-thumb">
                              <div class="blog-image">
                                   <img src="<?php  echo $cikti['url']; ?>" class="img-responsive" alt="Blog Image">
                              </div>
                              <h2><?php  ?></h2>
                              <p>Resimleriyle <?php  echo $cikti['isim']; ?> çümbüşü yaratan sanatçı Svetlana Eremeeva‘nın <?php  echo $cikti['isim']; ?> hoş <?php  echo $cikti['isim']; ?>. Renk geçişleri ile ön plana çıkan <?php  echo $cikti['isim']; ?> canlılık konusunda oldukça dikkatli. Özellikle <?php  echo $cikti['isim']; ?> mora doğru uzanan ara <?php  echo $cikti['isim']; ?> yaptığı resimlere yansıtan <?php  echo $cikti['isim']; ?> Eremeeva genellikle çiçekleri kullanıyor.

                    Çiçek, portre ve anı gibi temalar belirleyen <?php  echo $cikti['isim']; ?> Svetlana Eremeeva‘dan derlediklerimiz aşağıda. <?php  echo $cikti['isim']; ?> verici seyirler.</p>

                             <h1>Şifresiz Beğeni , Şifresiz Takipçi</h1>
                             
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- FOOTER -->
  <footer data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-5 col-sm-12">
                         <div class="footer-thumb footer-info"> 
                              <h2>SOFTACE</h2>
                              <p>HER TÜRLÜ YAZILIM .</p>
                         </div>
                    </div>

                    

                    
                                

                    <div class="col-md-12 col-sm-12">
                         <div class="footer-bottom">
                              <div class="col-md-6 col-sm-5">
                                   <div class="copyright-text"> 
                                        <p>Copyright &copy; 2019 SOFTACE</p>
                                   </div>
                              </div>
                             
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>

     <!-- MODAL -->
    <section class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>SOFTACE</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                             <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>
                                             <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                             <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="#" method="post">
                                                       <input type="text" class="form-control" name="name" placeholder="Name" required>
                                                       <input type="telephone" class="form-control" name="telephone" placeholder="Telephone" required>
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
                                             </div>

                                             <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>

     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.stellar.min.js"></script>
     <script src="js/jquery.magnific-popup.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>