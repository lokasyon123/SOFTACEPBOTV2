<?php 
$host="localhost";
$vkad="tunahan_pinterest";
$vsif="Tunahan_pinterest53";
$vad="tunahan_pinterest";


 ?>