-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 17 Eyl 2019, 20:18:32
-- Sunucu sürümü: 10.1.40-MariaDB
-- PHP Sürümü: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `pinterest`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `id` int(55) NOT NULL,
  `admin` varchar(55) NOT NULL,
  `sifre` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `admin`, `sifre`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `anahtar`
--

CREATE TABLE `anahtar` (
  `id` int(55) NOT NULL,
  `kelime` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `anahtar`
--

INSERT INTO `anahtar` (`id`, `kelime`) VALUES
(18, 'sosyaling şifresiz beğeni'),
(19, 'sosyaling şifresiz takipçi'),
(20, 'sosyaling instagram şifresiz beğeni'),
(21, 'sosyaling instagram şifresiz takipçi'),
(22, 'şifresiz beğeni'),
(23, 'şifresiz takipçi'),
(24, 'oyun\r\n'),
(25, 'game\r\n'),
(26, 'hd wallpaper\r\n'),
(27, 'wallpaper hd\r\n'),
(28, '#game #room #design'),
(29, '#game #room #design'),
(30, '#game #room #design'),
(31, 'wallpaper\r\n'),
(32, 'oyun\r\n'),
(33, 'game\r\n'),
(34, 'hd wallpaper\r\n'),
(35, 'wallpaper hd\r\n'),
(36, '#game #room #design'),
(37, 'wallpaper\r\n'),
(38, 'oyun\r\n'),
(39, '#game #room #design'),
(40, 'hd wallpaper\r\n'),
(41, 'wallpaper hd\r\n'),
(42, '#game #room #design'),
(43, 'odun\r\n'),
(44, 'manzara\r\n'),
(45, 'wallpaper\r\n'),
(46, 'oyun\r\n'),
(47, 'game\r\n'),
(48, 'hd wallpaper\r\n'),
(49, 'wallpaper hd\r\n'),
(50, '4k wallpapaer');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

CREATE TABLE `blog` (
  `id` int(55) NOT NULL,
  `isim` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `aciklama` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `url` varchar(55) NOT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `degisken` varchar(5555) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`id`, `isim`, `aciklama`, `url`, `time`, `degisken`) VALUES
(24961, '#wallpaper\r\n', '#wallpaper\r\n', 'resimm/20987579.jpg', '2019-09-16 20:39:55', ''),
(46563, '#wallpaper hd\r\n', '#wallpaper hd\r\n', 'resimm/48817830.jpg', '2019-09-16 20:40:03', ''),
(89823, '#game\r\n', '#game\r\n', 'resimm/68952960.jpg', '2019-09-16 20:39:48', ''),
(91182, '#sosyaling instagram şifresiz beğeni', '#sosyaling instagram şifresiz beğeni', 'resimm/72809507.jpg', '2019-09-16 20:40:10', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bot`
--

CREATE TABLE `bot` (
  `id` int(55) NOT NULL,
  `mail` varchar(55) NOT NULL,
  `sifre` varchar(55) NOT NULL,
  `kadi` varchar(55) NOT NULL,
  `delay` varchar(55) NOT NULL,
  `miktar` varchar(55) NOT NULL,
  `durum` varchar(55) NOT NULL,
  `s` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `bot`
--

INSERT INTO `bot` (`id`, `mail`, `sifre`, `kadi`, `delay`, `miktar`, `durum`, `s`) VALUES
(1, 'SOFTACEV2BOT', 'SOFTACEV2BOT', 'SOFTACEV2BOT', '1', '999', '252', 'disabled');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `anahtar`
--
ALTER TABLE `anahtar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bot`
--
ALTER TABLE `bot`
  ADD PRIMARY KEY (`durum`),
  ADD UNIQUE KEY `durum` (`durum`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `anahtar`
--
ALTER TABLE `anahtar`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Tablo için AUTO_INCREMENT değeri `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91183;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
